(function(global,factory)){
    "use strict";
    if (typeof module ==="object" && typeof module.exports === "object") {
        
    }
}